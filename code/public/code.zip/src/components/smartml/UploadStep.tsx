import { useRef, useState } from "react";
import { UploadCloud, FileSpreadsheet, FileJson, FileText, CheckCircle2 } from "lucide-react";

interface UploadStepProps {
  onUploaded: (file: File) => void;
}

const ACCEPTED = [".csv", ".xlsx", ".xls", ".json"];

export function UploadStep({ onUploaded }: UploadStepProps) {
  const [dragOver, setDragOver] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<"idle" | "uploading" | "done">("idle");
  const [file, setFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (f: File) => {
    setFile(f);
    setStatus("uploading");
    setProgress(0);
    const steps = ["Reading file…", "Parsing schema…", "Validating rows…", "Handshake complete"];
    let p = 0;
    const timer = setInterval(() => {
      p += 8 + Math.random() * 12;
      setProgress(Math.min(100, Math.round(p)));
      if (p >= 100) {
        clearInterval(timer);
        setStatus("done");
        setTimeout(() => onUploaded(f), 400);
      }
    }, 140);
    void steps;
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };

  return (
    <div className="animate-fade-in-up mx-auto max-w-4xl">
      <div className="mb-10 text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1.5 text-xs font-medium shadow-[var(--glow-primary)]">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald animate-pulse-glow" />
          <span className="uppercase tracking-widest text-[10px] text-foreground/80">Step 1 · Upload</span>
          <span className="text-muted-foreground">Drop your dataset to begin</span>
        </div>
        <h1 className="text-5xl font-bold tracking-tight md:text-6xl">
          Ship a model in
          <br />
          <span className="text-gradient">under 60 seconds.</span>
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground">
          Drop a dataset. SmartML inspects it, trains <span className="text-foreground font-semibold">10 algorithms</span> in parallel, and hands back deployable code.
        </p>
      </div>

      <label
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={`conic-ring relative flex cursor-pointer flex-col items-center justify-center overflow-hidden rounded-3xl border border-dashed p-16 text-center transition-all ${
          dragOver ? "border-primary/70 bg-primary/10 scale-[1.01]" : "border-border/70 bg-card/50 backdrop-blur-xl"
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED.join(",")}
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />
        <div className={`mb-5 flex h-20 w-20 items-center justify-center rounded-2xl bg-[image:var(--gradient-primary)] shadow-[var(--glow-primary)] ${status === "uploading" ? "animate-pulse-glow" : "animate-float"}`}>
          {status === "done" ? <CheckCircle2 className="h-9 w-9 text-white" /> : <UploadCloud className="h-9 w-9 text-white" />}
        </div>
        <div className="text-lg font-semibold">
          {status === "idle" && "Drop your file here, or click to browse"}
          {status === "uploading" && "Uploading…"}
          {status === "done" && "Upload complete"}
        </div>
        <div className="mt-1 text-sm text-muted-foreground">
          {file ? file.name : "CSV · Excel (.xlsx, .xls) · JSON — up to 200 MB"}
        </div>

        {status === "uploading" && (
          <div className="mt-6 w-full max-w-sm">
            <div className="h-2 overflow-hidden rounded-full bg-secondary">
              <div className="h-full rounded-full bg-[image:var(--gradient-primary)] transition-all" style={{ width: `${progress}%` }} />
            </div>
            <div className="mt-2 flex justify-between text-xs text-muted-foreground">
              <span>Streaming to worker…</span>
              <span className="font-mono">{progress}%</span>
            </div>
          </div>
        )}

        {status === "idle" && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="mt-6 rounded-xl btn-gradient px-5 py-2.5 text-sm font-semibold"
          >
            Choose file
          </button>
        )}
      </label>

      <div className="mt-6 grid grid-cols-1 gap-3 md:grid-cols-3">
        {[
          { icon: FileSpreadsheet, label: "CSV", desc: "Comma-separated" },
          { icon: FileSpreadsheet, label: "Excel", desc: ".xlsx, .xls" },
          { icon: FileJson, label: "JSON", desc: "Array of records" },
        ].map((f) => (
          <div key={f.label} className="glass-panel flex items-center gap-3 rounded-xl p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <f.icon className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-semibold">{f.label}</div>
              <div className="text-xs text-muted-foreground">{f.desc}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 flex items-center justify-center gap-2 text-xs text-muted-foreground">
        <FileText className="h-3.5 w-3.5" />
        No dataset? Try our <button className="text-primary underline underline-offset-2 hover:text-violet">Sample churn dataset</button>
      </div>
    </div>
  );
}
