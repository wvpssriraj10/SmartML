import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { Navbar } from "@/components/smartml/Navbar";
import { type ChatMessage } from "@/components/smartml/ChatSidebar";
import { ChatFab } from "@/components/smartml/ChatFab";
import { UploadStep } from "@/components/smartml/UploadStep";
import { AnalyzingStep } from "@/components/smartml/AnalyzingStep";
import { InspectionStep } from "@/components/smartml/InspectionStep";
import { TrainingStep } from "@/components/smartml/TrainingStep";
import { ResultsStep } from "@/components/smartml/ResultsStep";
import { mockInspect, mockResults, resetMockCounter, nextMockCounter, type InspectionResult, type ModelResult } from "@/lib/smartml-mock";
import { Check } from "lucide-react";

export const Route = createFileRoute("/")({
  component: SmartMLApp,
});

type Step = "upload" | "analyzing" | "inspection" | "training" | "results";

const STEPS: { key: Step; label: string }[] = [
  { key: "upload", label: "Upload" },
  { key: "analyzing", label: "Analyze" },
  { key: "inspection", label: "Configure" },
  { key: "training", label: "Train" },
  { key: "results", label: "Results" },
];

function makeId() {
  return Math.random().toString(36).slice(2, 10);
}

function SmartMLApp() {
  const [step, setStep] = useState<Step>("upload");
  const [file, setFile] = useState<File | null>(null);
  const [inspection, setInspection] = useState<InspectionResult | null>(null);
  const [trainCfg, setTrainCfg] = useState<{ target: string; problemType: "auto" | "classification" | "regression" } | null>(null);
  const [results, setResults] = useState<ModelResult[] | null>(null);

  const [chat, setChat] = useState<ChatMessage[]>([
    {
      id: makeId(),
      role: "assistant",
      content: "Welcome to SmartML. Drop a dataset on the left and I'll guide you through inspection, training, and deployment — right here in this chat.",
    },
  ]);

  const chatCtx = useMemo(
    () => ({ hasDataset: !!inspection, target: trainCfg?.target ?? inspection?.suggestedTarget }),
    [inspection, trainCfg],
  );

  const pushUser = (content: string) =>
    setChat((c) => [...c, { id: makeId(), role: "user", content }]);
  const pushAssistant = (content: string) =>
    setChat((c) => [...c, { id: makeId(), role: "assistant", content }]);

  const resolvedProblem: "classification" | "regression" =
    trainCfg?.problemType === "regression" ? "regression" :
    trainCfg?.problemType === "classification" ? "classification" :
    inspection?.suggestedProblem ?? "classification";

  const handleUploaded = (f: File) => {
    setFile(f);
    setStep("analyzing");
    pushAssistant(`Received "${f.name}". Kicking off inspection — I'll surface schema, missing rates, and a target suggestion in a moment.`);
  };

  const handleAnalyzed = () => {
    const insp = mockInspect(file?.name ?? "dataset.csv", nextMockCounter());
    setInspection(insp);
    setStep("inspection");
    pushAssistant(
      `Inspection complete — ${insp.rows.toLocaleString()} rows × ${insp.cols} columns, quality ${insp.qualityScore}/100. I'd recommend "${insp.suggestedTarget}" as the target for a ${insp.suggestedProblem} problem.`,
    );
  };

  const handleStartTraining = (cfg: { target: string; problemType: "auto" | "classification" | "regression"; strategy: string }) => {
    setTrainCfg(cfg);
    setStep("training");
    pushAssistant(`Training 10 models to predict "${cfg.target}" — I'll narrate progress and highlight the champion when it emerges.`);
  };

  const handleTrainingDone = () => {
    const r = mockResults(resolvedProblem);
    setResults(r);
    setStep("results");
    pushAssistant(`Done! "${r[0]!.name}" took the crown. Open the leaderboard for the full ranking, or download the deployable bundle when you're ready.`);
  };

  const handleNewSession = () => {
    resetMockCounter();
    setStep("upload");
    setFile(null);
    setInspection(null);
    setTrainCfg(null);
    setResults(null);
    setChat([{
      id: makeId(),
      role: "assistant",
      content: "Fresh session ready. Drop another dataset whenever you like.",
    }]);
  };

  const handleDownload = () => {
    pushAssistant("Packaging model + FastAPI wrapper + requirements.txt into smartml_deploy.zip…");
    // Simulate a small text download so the button feels real.
    const blob = new Blob(
      [`# SmartML Export\n# Champion: ${results?.[0]?.name}\n# Target: ${trainCfg?.target}\n`],
      { type: "text/plain" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "smartml_deploy.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  const currentIdx = STEPS.findIndex((s) => s.key === step);

  return (
    <div className="min-h-screen">
      <Navbar onNewSession={handleNewSession} />

      <div className="mx-auto grid max-w-[1400px] grid-cols-1 gap-6 px-6 py-6">
        <main className="min-w-0">
          {/* Stepper */}
          <div className="mb-8 flex items-center gap-2 overflow-x-auto pb-1">
            {STEPS.map((s, i) => {
              const done = i < currentIdx;
              const active = i === currentIdx;
              return (
                <div key={s.key} className="flex items-center gap-2">
                  <div className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs transition ${
                    active ? "border-primary/60 bg-primary/15 text-foreground" :
                    done ? "border-emerald/40 bg-emerald/10 text-emerald" :
                    "border-border/60 text-muted-foreground"
                  }`}>
                    <span className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold ${
                      active ? "bg-[image:var(--gradient-primary)] text-white" :
                      done ? "bg-emerald text-background" :
                      "bg-muted text-muted-foreground"
                    }`}>
                      {done ? <Check className="h-3 w-3" /> : i + 1}
                    </span>
                    <span className="font-medium">{s.label}</span>
                  </div>
                  {i < STEPS.length - 1 && <span className={`h-px w-6 ${i < currentIdx ? "bg-emerald/50" : "bg-border"}`} />}
                </div>
              );
            })}
          </div>

          {step === "upload" && <UploadStep onUploaded={handleUploaded} />}
          {step === "analyzing" && <AnalyzingStep fileName={file?.name ?? "dataset"} onDone={handleAnalyzed} />}
          {step === "inspection" && inspection && (
            <InspectionStep inspection={inspection} onStartTraining={handleStartTraining} />
          )}
          {step === "training" && trainCfg && (
            <TrainingStep onDone={handleTrainingDone} target={trainCfg.target} problemType={trainCfg.problemType} />
          )}
          {step === "results" && results && inspection && (
            <ResultsStep
              results={results}
              problemType={resolvedProblem}
              columns={inspection.columns}
              target={trainCfg?.target}
              onNewSession={handleNewSession}
              onDownload={handleDownload}
            />
          )}

        </main>
      </div>

      <ChatFab
        messages={chat}
        onSend={pushUser}
        onAssistantReply={pushAssistant}
        context={chatCtx}
      />
    </div>
  );
}
